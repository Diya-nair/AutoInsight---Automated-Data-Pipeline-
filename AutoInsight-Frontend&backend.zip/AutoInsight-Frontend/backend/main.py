from fastapi import FastAPI, Query
from fastapi.responses import FileResponse
from sqlalchemy import create_engine, func, or_
from sqlalchemy.orm import sessionmaker
import pandas as pd

from database import engine, SessionLocal
from models import Base, Customer

app = FastAPI()

# Create tables
Base.metadata.create_all(bind=engine)


# Load CSV data into database
def load_csv_to_db():
    db = SessionLocal()
    df = pd.read_csv("customers-100.csv")

    for _, row in df.iterrows():
        customer = Customer(
            first_name=row["First Name"],
            last_name=row["Last Name"],
            company=row["Company"],
            city=row["City"],
            country=row["Country"],
            email=row["Email"]
        )
        db.add(customer)

    db.commit()
    db.close()


# Call once
load_csv_to_db()


@app.get("/")
def home():
    return {"message": "AutoInsight API Running"}


# Search Customer
@app.get("/search_customer")
def search_customer(name: str = Query(...)):
    db = SessionLocal()

    results = db.query(Customer).filter(
        or_(
            Customer.first_name.contains(name),
            Customer.last_name.contains(name)
        )
    ).all()

    return results


# Top Countries
@app.get("/top_countries")
def top_countries():
    db = SessionLocal()

    results = db.query(
        Customer.country,
        func.count(Customer.id)
    ).group_by(Customer.country).all()

    return results


# Export CSV
@app.get("/export_csv")
def export_csv():
    db = SessionLocal()
    customers = db.query(Customer).all()

    data = []
    for c in customers:
        data.append({
            "First Name": c.first_name,
            "Last Name": c.last_name,
            "Company": c.company,
            "City": c.city,
            "Country": c.country,
            "Email": c.email
        })

    df = pd.DataFrame(data)
    file_path = "exported_customers.csv"
    df.to_csv(file_path, index=False)

    return FileResponse(file_path, filename="customers.csv")


# Export Excel
@app.get("/export_excel")
def export_excel():
    db = SessionLocal()
    customers = db.query(Customer).all()

    data = []
    for c in customers:
        data.append({
            "First Name": c.first_name,
            "Last Name": c.last_name,
            "Company": c.company,
            "City": c.city,
            "Country": c.country,
            "Email": c.email
        })

    df = pd.DataFrame(data)
    file_path = "exported_customers.xlsx"
    df.to_excel(file_path, index=False)

    return FileResponse(file_path, filename="customers.xlsx")